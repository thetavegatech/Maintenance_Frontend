import React from 'react'
import axios from 'axios'
import { NavLink } from 'react-router-dom'
import dlt from '../assetTable/delete.png'
import { CTable } from '@coreui/react'

class AssetTable extends React.Component {
  // constructor(props) {
  //   super(props)

  //   this.state = {
  //     assets: [],
  //   }
  // }
  state = {
    assets: [],
  }

  // getNextScheduleDate(startDate, frequency) {
  //   const newDate = new Date(startDate)

  //   switch (frequency.toLowerCase()) {
  //     case 'daily':
  //       newDate.setDate(newDate.getDate() + 1)
  //       break
  //     case 'weekly':
  //       newDate.setDate(newDate.getDate() + 7)
  //       break
  //     case 'fifteen days':
  //       newDate.setDate(newDate.getDate() + 15)
  //       break
  //     case 'monthly':
  //       newDate.setMonth(newDate.getMonth() + 1)
  //       break
  //     case 'quarterly':
  //       newDate.setMonth(newDate.getMonth() + 3)
  //       break
  //     case 'half year':
  //       newDate.setMonth(newDate.getMonth() + 6)
  //       break
  //     case 'yearly':
  //       newDate.setFullYear(newDate.getFullYear() + 1)
  //       break
  //     default:
  //       throw new Error('Unsupported frequency')
  //   }

  //   return newDate.toISOString().split('T')[0]
  // }

  // componentDidMount() {
  //   this.fetchData()
  //   this.updateNextDate = this.updateNextDate.bind(this)

  //   // Calculate the time remaining until 11:55 PM
  //   const now = new Date()
  //   const targetTime = new Date()
  //   targetTime.setHours(23, 55, 0, 0)
  //   let timeRemaining = targetTime - now

  //   // Ensure the timeRemaining is positive (i.e., not in the past)
  //   if (timeRemaining < 0) {
  //     timeRemaining += 24 * 60 * 60 * 1000 // Add 24 hours in milliseconds
  //   }

  //   // Use setTimeout to run the updateNextDate function
  //   setTimeout(() => {
  //     this.updateNextDate()
  //     // Set an interval to repeat the function every 24 hours
  //     this.updateInterval = setInterval(this.updateNextDate, 24 * 60 * 60 * 1000)
  //   }, timeRemaining)

  //   axios
  //     .get('http://localhost:5000/getAllData')
  //     .then((response) => {
  //       this.setState({ assets: Array.isArray(response.data) ? response.data : [response.data] })
  //     })
  //     .catch((error) => {
  //       console.error('Error fetching data:', error)
  //       alert('Error fetching data')
  //     })
  // }
  componentDidMount() {
    this.fetchData()
    // Start the periodic update of the "Next Date"
    // this.updateNextDate()
    this.updateNextDate = this.updateNextDate.bind(this)
    // Start the periodic update of the "Next Date" every second
    this.updateInterval = setInterval(this.updateNextDate, 1 * 60 * 1000)
    axios
      .get('http://192.168.29.137:5000/getAllData') // Adjust the endpoint if necessary
      .then((response) => {
        // If the response is an array, simply set it to assets.
        // If it's an object, place it in an array as you've shown.
        this.setState({ assets: Array.isArray(response.data) ? response.data : [response.data] })
      })
      .catch((error) => {
        console.error('Error fetching data:', error)
        alert('Error fetching data')
      })
  }

  componentWillUnmount() {
    clearInterval(this.updateInterval)
  }

  fetchData() {
    axios
      .get('http://192.168.29.137:5000/getAllData')
      .then((response) => {
        this.setState({ assets: Array.isArray(response.data) ? response.data : [response.data] })
      })
      .catch((error) => {
        console.error('Error fetching data:', error)
        alert('Error fetching data')
      })
  }

  deleteData(id) {
    const isConfirmed = window.confirm('Are you sure you want to delete this data?')
    if (isConfirmed) {
      axios
        .delete(`http://192.168.29.137:5000/deleteRecord/${id}`)
        .then((response) => {
          console.log('Data deleted:', response.data)

          // Delete from frontend
          const index = this.state.assets.findIndex((asset) => asset._id === id)
          if (index !== -1) {
            const newAssets = [...this.state.assets]
            newAssets.splice(index, 1)
            this.setState({
              assets: newAssets,
              message: 'Data successfully deleted!',
            })
          }
        })
        .catch((error) => {
          console.error('Error deleting data:', error)
          this.setState({
            message: 'Error deleting data. Please try again.',
          })
        })
    }
  }

  updateNextDate() {
    const today = new Date()
    const { assets } = this.state || {}

    if (!assets) {
      return
    }

    // Update "Next Date" for each asset based on its frequency
    const updatedAssets = assets.map((asset) => {
      const nextDate = new Date(asset.nextDate)

      if (today >= nextDate) {
        let frequency = asset.ScheduledMaintenanceDatesandIntervals
          ? asset.ScheduledMaintenanceDatesandIntervals.toLowerCase()
          : 'daily' // Default to "daily" if frequency is undefined

        let daysToAdd = null // Default to adding 1 day

        // Determine the number of days to add based on the frequency
        switch (frequency) {
          case 'daily':
            daysToAdd = 1
            break
          case 'weekly':
            daysToAdd = 7
            break
          case 'fifteen days':
            daysToAdd = 15
            break
          case 'monthly':
            // Assuming a month has 30 days, adjust as needed
            daysToAdd = 30
            break
          case 'quarterly':
            // Assuming a quarter has 90 days, adjust as needed
            daysToAdd = 90
            break
          case 'half year':
            // Assuming half a year has 180 days, adjust as needed
            daysToAdd = 180
            break
          case 'yearly':
            // Assuming a year has 365 days, adjust as needed
            daysToAdd = 365
            break
          default:
            console.error(`Unsupported frequency for task: ${asset.TaskName}`)
            // Handle unsupported frequency by defaulting to "daily"
            frequency = 'daily'
            daysToAdd = ''
        }

        // Add the calculated number of days to the nextDate
        nextDate.setDate(nextDate.getDate() + daysToAdd)
        asset.nextDate = nextDate.toISOString().split('T')[0]
      }

      return asset
    })

    this.setState({ assets: updatedAssets }, () => {
      // After updating the state, send the updated data to the backend API
      axios
        .post('http://localhost:5000/updateRecords', { assets: updatedAssets })
        .then((response) => {
          console.log('Next Date updated in the database:', response.data)
        })
        .catch((error) => {
          console.error('Error updating Next Date in the database:', error)
        })
    })
  }

  render() {
    const { assets } = this.state // Destructuring assets from state for ease of access
    // Check if assets exist before rendering
    if (!assets) {
      return null // or a loading indicator if you prefer
    }
    // Filter assets to only include rows with a non-empty "Task Name"
    const filteredAssets = assets.filter((asset) => asset.TaskName && asset.TaskName.trim() !== '')

    return (
      <div className="container">
        {/* <div className="table-controls"> */}

        <NavLink to="/taskForm">
          {' '}
          <button className="btn btn-primary mb-2" style={{ marginTop: '5px' }}>
            {' '}
            Add New{' '}
          </button>{' '}
        </NavLink>

        {/* <NavLink to="/todaysTask"><button className="btn btn-primary mb-2" >  Show today's Task</button>  </NavLink> */}
        {/* </div> */}
        <CTable bordered borderColor="primary">
          {/* <table className="table table-hover table-responsive"> */}
          <thead className="thead-dark">
            <tr>
              <th>Task Name</th>
              <th>Task Description</th>
              <th>Schedule Maintenance</th>
              <th>Start Date</th>
              <th>Next Date</th>
              <th>Status</th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {this.state.message && (
              <tr>
                <td colSpan="8">{this.state.message}</td>
              </tr>
            )}
            {filteredAssets.map((asset) => (
              <tr key={asset._id}>
                <td>{asset.TaskName}</td>
                <td>{asset.TaskDescription}</td>
                <td>{asset.ScheduledMaintenanceDatesandIntervals}</td>
                {/* <td>{asset.startDate}</td> */}
                <td>{new Date(asset.startDate).toISOString().split('T')[0]}</td>
                <td>{new Date(asset.nextDate).toISOString().split('T')[0]}</td>
                <td>{asset.status}</td>
                <td>
                  <NavLink to={`/editTask/${asset._id}`}>
                    <button>✎</button>
                  </NavLink>
                </td>

                <td>
                  <button className="delete-button" onClick={() => this.deleteData(asset._id)}>
                    <img src={dlt} alt="" width={30} height={30} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          {/* </table> */}
        </CTable>
      </div>
    )
  }
}

export default AssetTable
