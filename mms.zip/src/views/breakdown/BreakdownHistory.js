import React from 'react'
import axios from 'axios'
import { NavLink } from 'react-router-dom'
import {
  CAvatar,
  CButton,
  CButtonGroup,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CProgress,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react'

class BreakdownHistory extends React.Component {
  state = {
    breakdowns: [],
    selectedMachine: '',
    // mtbf: '',
    mttr: '',
  }

  componentDidMount() {
    axios
      .get('http://192.168.29.137:5000/getBreakdownData')
      .then((response) => {
        this.setState({
          breakdowns: Array.isArray(response.data) ? response.data : [response.data],
        })
      })
      .catch((error) => {
        console.error('Error fetching data:', error)
        alert('Error fetching data')
      })
  }

  calculateMTTR = () => {
    const { breakdowns, selectedMachine } = this.state

    if (!selectedMachine) {
      this.setState({ mttr: 'Please select a machine.' })
      return
    }

    const filteredBreakdowns = breakdowns.filter(
      (breakdown) => breakdown.MachineName === selectedMachine,
    )

    if (filteredBreakdowns.length === 0) {
      this.setState({ mttr: 'No breakdowns found for selected machine.' })
      return
    }

    let totalRepairTimeMs = 0

    filteredBreakdowns.forEach((breakdown) => {
      const startDate = new Date(breakdown.BreakdownStartDate)
      const endDate = new Date(breakdown.BreakdownEndDate)
      const repairTimeMs = endDate - startDate
      totalRepairTimeMs += repairTimeMs
    })

    const totalRepairTimeHours = totalRepairTimeMs / (1000 * 3600) // Convert milliseconds to hours

    const mttr = totalRepairTimeHours / filteredBreakdowns.length

    this.setState({ mttr })
  }

  calculateMTBF = () => {
    const { breakdowns, selectedMachine } = this.state

    if (!selectedMachine) {
      this.setState({ mtbf: 'Please select a machine.' })
      return
    }

    const filteredBreakdowns = breakdowns.filter(
      (breakdown) => breakdown.MachineName === selectedMachine,
    )

    if (filteredBreakdowns.length === 0) {
      this.setState({ mtbf: 'No breakdowns found for selected machine.' })
      return
    }

    const fixedOperatingTime = 208 * 3600 * 1000 // 8 hours in milliseconds
    const numberOfFailures = filteredBreakdowns.length

    const mtbf = fixedOperatingTime / (numberOfFailures * 1000 * 3600) // Convert milliseconds to hours

    this.setState({ mtbf })
  }

  render() {
    // const { breakdowns, selectedMachine, mttr } = this.state;
    const { breakdowns, selectedMachine, mtbf, mttr } = this.state
    const openBreakdowns = breakdowns.filter((breakdown) => breakdown.Status === 'close')

    return (
      <>
        <div className="container">
          <CTable bordered borderColor="primary">
            <thead className="thead-dark">
              <tr>
                <th>MachineName</th>
                <th>BreakDownStartDate</th>
                <th>Shift</th>
                <th>LineName</th>
                <th>StageName</th>
                <th>End Date</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {this.state.message && (
                <tr>
                  <td colSpan="8">{this.state.message}</td>
                </tr>
              )}
              {openBreakdowns.map((breakdown) => (
                <tr key={breakdown._id}>
                  <td>{breakdown.MachineName}</td>
                  <td>{breakdown.BreakdownStartDate}</td>
                  <td>{breakdown.Shift}</td>
                  <td>{breakdown.LineName}</td>
                  <td>{breakdown.StageName}</td>
                  <td>{breakdown.BreakdownEndDate}</td>
                  <td>{breakdown.Status}</td>
                  <td>
                    <NavLink to={`/pbdStatus/${breakdown._id}`}>
                      <button>✎</button>
                    </NavLink>
                  </td>
                </tr>
              ))}
            </tbody>
          </CTable>
          {/* <div className="container">
            <div className="row g-2">
              <div className="col-md-5">
                <label>Select Machine: </label>
                <select
                  onChange={(e) => {
                    this.setState({ selectedMachine: e.target.value }, this.calculateMTBF)
                  }}
                  value={selectedMachine}
                >
                  <option value="">Select Machine</option>
                  {Array.from(new Set(breakdowns.map((breakdown) => breakdown.MachineName))).map(
                    (machineName) => (
                      <option key={machineName} value={machineName}>
                        {machineName}
                      </option>
                    ),
                  )}
                </select>
                <button onClick={this.calculateMTBF}>Calculate MTBF</button>
              </div>
              <div>
                <label>MTBF (hours): </label>
                <input type="text" value={mtbf} readOnly />
              </div>

              <div className="col-md-5">
                <label>Select Machine: </label>
                <select
                  onChange={(e) => {
                    this.setState({ selectedMachine: e.target.value }, this.calculateMTTR)
                  }}
                  value={selectedMachine}
                >
                  <option value="">Select Machine</option>
                  {Array.from(new Set(breakdowns.map((breakdown) => breakdown.MachineName))).map(
                    (machineName) => (
                      <option key={machineName} value={machineName}>
                        {machineName}
                      </option>
                    ),
                  )}
                </select>
                <button onClick={this.calculateMTTR}>Calculate MTTR</button>
              </div>
              <div>
                <label>MTTR (hours): </label>
                <input type="text" value={mttr} readOnly />
              </div>
            </div>
          </div> */}
          <div className="container">
            <div className="row g-2">
              <div className="col-md-6">
                <label>Select Machine: </label>
                <select
                  onChange={(e) => {
                    this.setState({ selectedMachine: e.target.value }, this.calculateMTBF)
                  }}
                  value={selectedMachine}
                >
                  <option value="">Select Machine</option>
                  {Array.from(new Set(breakdowns.map((breakdown) => breakdown.MachineName))).map(
                    (machineName) => (
                      <option key={machineName} value={machineName}>
                        {machineName}
                      </option>
                    ),
                  )}
                </select>
                <button onClick={this.calculateMTBF}>Calculate MTBF</button>
              </div>
              <div className="col-md-6">
                <label style={{ marginLeft: '-20%' }}>MTBF (hours): </label>
                <input type="text" value={mtbf} readOnly />
              </div>

              <div className="col-md-6">
                <label>Select Machine: </label>
                <select
                  onChange={(e) => {
                    this.setState({ selectedMachine: e.target.value }, this.calculateMTTR)
                  }}
                  value={selectedMachine}
                >
                  <option value="">Select Machine</option>
                  {Array.from(new Set(breakdowns.map((breakdown) => breakdown.MachineName))).map(
                    (machineName) => (
                      <option key={machineName} value={machineName}>
                        {machineName}
                      </option>
                    ),
                  )}
                </select>
                <button onClick={this.calculateMTTR}>Calculate MTTR</button>
              </div>
              <div className="col-md-6">
                <label style={{ marginLeft: '-20%' }}>MTTR (hours): </label>
                <input type="text" value={mttr} readOnly />
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }
}

export default BreakdownHistory
