import React from 'react'
// import BDList from './BDList';
import axios from 'axios'
import { NavLink } from 'react-router-dom'
import {
  CAvatar,
  CButton,
  CButtonGroup,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CProgress,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react'

class BDList extends React.Component {
  state = {
    breakdowns: [],
  }

  componentDidMount() {
    axios
      .get('http://192.168.29.137:5000/getBreakdownData') // Adjust the endpoint if necessary
      .then((response) => {
        // If the response is an array, simply set it to assets.
        // If it's an object, place it in an array as you've shown.
        this.setState({
          breakdowns: Array.isArray(response.data) ? response.data : [response.data],
        })
      })
      .catch((error) => {
        console.error('Error fetching data:', error)
        alert('Error fetching data')
      })
  }

  render() {
    const { breakdowns } = this.state
    const openBreakdowns = breakdowns.filter((breakdown) => breakdown.Status === 'open')
    return (
      <>
        <div className="container">
          {/* </div> */}
          {/* <div className="table-controls"> */}

          {/* <NavLink to="/breakdownForm">
            {' '}
            <button
              className="btn btn-primary mb-2"
              //   style={{ marginRight: '50px', marginTop: '45px' }}
            >
              {' '}
              Add New{' '}
            </button>{' '}
          </NavLink> */}

          {/* <NavLink to="/todaysTask"><button className="btn btn-primary mb-2" >  Show today's Task</button>  </NavLink> */}
          {/* </div> */}
          {/* <div className="add" style={{ marginLeft: "300px" }}> */}
          {/* <h3> Breakdown ListView</h3> */}
          {/* </div> */}
          {/* <div className="container" style={{ marginRight: "50px", marginTop: "0px" }}> */}
          <CTable bordered borderColor="primary">
            {/* <table className="table table-hover table-responsive"> */}
            <thead className="thead-dark">
              <tr>
                <th>MachineName</th>
                <th>BreakDownStartDate</th>
                <th>Shift</th>
                <th>LineName</th>
                <th>StageName</th>
                {/* <th>BreakdownPhenomenons</th> */}
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {this.state.message && (
                <tr>
                  <td colSpan="8">{this.state.message}</td>
                </tr>
              )}
              {openBreakdowns.map((breakdown) => (
                <tr key={breakdown._id}>
                  <td>{breakdown.MachineName}</td>
                  <td>{breakdown.BreakdownStartDate}</td>
                  <td>{breakdown.Shift}</td>
                  <td>{breakdown.LineName}</td>
                  <td>{breakdown.StageName}</td>
                  {/* <td>{breakdown.BreakdownPhenomenons}</td> */}
                  <td>{breakdown.Status}</td>
                  <td>
                    <NavLink to={`/productionBD/${breakdown._id}`}>
                      <button>✎</button>
                    </NavLink>
                  </td>

                  {/* <NavLink to='/editForm'>
                                        <button>✎</button>
                                    </NavLink> */}
                </tr>
              ))}
            </tbody>
            {/* </table> */}
          </CTable>
        </div>
      </>
    )
  }
}
export default BDList
