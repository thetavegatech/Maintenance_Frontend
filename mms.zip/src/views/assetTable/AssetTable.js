import React from 'react'
import axios from 'axios'
import { NavLink } from 'react-router-dom'
import dlt from '../assetTable/delete.png'
import { CTable } from '@coreui/react'

class AssetTable extends React.Component {
  state = {
    assets: [],
  }

  componentDidMount() {
    axios
      .get('http://192.168.29.137:5000/getAllData') // Adjust the endpoint if necessary
      .then((response) => {
        // If the response is an array, simply set it to assets.
        // If it's an object, place it in an array as you've shown.
        this.setState({ assets: Array.isArray(response.data) ? response.data : [response.data] })
      })
      .catch((error) => {
        console.error('Error fetching data:', error)
        alert('Error fetching data')
      })
  }

  deleteData(id) {
    const isConfirmed = window.confirm('Are you sure you want to delete this data?')
    if (isConfirmed) {
      // Delete from backend (assuming you have a backend API to call)
      // axios.delete(`http://localhost:5000/deleteRecord/:id`)
      axios
        .delete(`http://192.168.29.137:5000/deleteRecord/${id}`)

        .then((response) => {
          console.log('Data deleted:', response.data)

          // Delete from frontend
          const index = this.state.data.findIndex((asset) => asset._id === id)
          if (index !== -1) {
            const newData = [...this.state.data]
            newData.splice(index, 1)
            this.setState({
              data: newData,
              message: 'Data successfully deleted!',
            })
          }
        })
        .catch((error) => {
          console.error('Error deleting data:', error)
          this.setState({
            message: 'Error deleting data. Please try again.',
          })
        })
    }
  }

  render() {
    const { assets } = this.state // Destructuring assets from state for ease of access

    return (
      <>
        <div className="container">
          {/* <div className="table-controls"> */}

          <NavLink to="/assetForm">
            {' '}
            <button className="btn btn-primary mb-2" style={{ marginTop: '5px' }}>
              {' '}
              Add New{' '}
            </button>{' '}
          </NavLink>

          {/* <NavLink to="/todaysTask"><button className="btn btn-primary mb-2" >  Show today's Task</button>  </NavLink> */}
          {/* </div> */}
          <CTable bordered borderColor="primary">
            {/* <table className="table table-hover table-responsive"> */}
            <thead className="thead-dark">
              <tr>
                <th>Asset Name</th>
                <th>Description</th>
                {/* <th>Location</th> */}
                <th>Model No</th>
                <th></th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {this.state.message && (
                <tr>
                  <td colSpan="8">{this.state.message}</td>
                </tr>
              )}
              {assets.map((asset) => (
                <tr key={asset._id}>
                  <td>{asset.AssetName}</td>
                  <td>{asset.Description}</td>
                  <td>{asset.Location}</td>
                  <td>
                    <NavLink to={`/editasset/${asset._id}`}>
                      <button>✎</button>
                    </NavLink>
                  </td>

                  <td>
                    <button className="delete-button" onClick={() => this.deleteData(asset._id)}>
                      <img src={dlt} alt="" width={30} height={30} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            {/* </table> */}
          </CTable>
        </div>
        {/* </div> */}
      </>
    )
  }
}

export default AssetTable
